setwd("C:\\Users\\mgkis\\OneDrive\\Desktop\\ps 6")
# Exercise
# 01)
# i) Binomial Distribution
# ii)
pbinom(46,50,0.85,lower.tail = FALSE)

# 02)
# i) Number of customer calls per hour
# ii) Poisson Distribution
# iii) 
dpois(15,12)